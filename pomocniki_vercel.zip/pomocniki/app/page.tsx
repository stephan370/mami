"use client";
import { useEffect, useState, useCallback, useRef } from "react";
import { ref, onValue, set, remove } from "firebase/database";
import { db } from "@/lib/firebase";
import {
  TASKS, DEFAULT_MEMBERS, AVATAR_COLORS,
  DAY_NAMES, DAY_NAMES_LONG, MONTH_NAMES_LONG, MONTH_NAMES_SHORT,
  START_DATE, WEEKS, SlotsData, TaskKey,
} from "@/lib/types";

function dk(d: Date) { return d.toISOString().slice(0, 10); }
function weekDays(w: number) {
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(START_DATE);
    d.setDate(START_DATE.getDate() + w * 7 + i);
    return d;
  });
}
function ini(n: string) { return n.slice(0, 2).toUpperCase(); }
function aStyle(i: number) {
  const [bg, fg] = AVATAR_COLORS[i % AVATAR_COLORS.length];
  return { background: bg, color: fg };
}

export default function App() {
  const [members, setMembers] = useState<string[]>(DEFAULT_MEMBERS);
  const [slots, setSlots] = useState<SlotsData>({});
  const [currentUser, setCurrentUser] = useState("");
  const [currentWeek, setCurrentWeek] = useState(0);
  const [screen, setScreen] = useState<"login" | "urnik" | "clani" | "pregled">("login");
  const [pendingSlot, setPendingSlot] = useState<{ dateKey: string; taskKey: TaskKey } | null>(null);
  const [modal, setModal] = useState<"slot" | "user" | null>(null);
  const [newMember, setNewMember] = useState("");
  const [toast, setToast] = useState("");
  const [syncing, setSyncing] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Firebase listeners
  useEffect(() => {
    const membersRef = ref(db, "data/members");
    const slotsRef = ref(db, "data/slots");
    const unsubM = onValue(membersRef, (snap) => {
      const val = snap.val();
      if (val && Array.isArray(val)) setMembers(val);
    });
    const unsubS = onValue(slotsRef, (snap) => {
      const val = snap.val();
      setSlots(val || {});
    });
    return () => { unsubM(); unsubS(); };
  }, []);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 2500);
  }, []);

  const saveSlots = useCallback(async (newSlots: SlotsData) => {
    setSyncing(true);
    await set(ref(db, "data/slots"), newSlots);
    setSyncing(false);
  }, []);

  const saveMembers = useCallback(async (newMembers: string[]) => {
    setSyncing(true);
    await set(ref(db, "data/members"), newMembers);
    setSyncing(false);
  }, []);

  // LOGIN
  function login(name: string) {
    setCurrentUser(name);
    setScreen("urnik");
  }

  // SLOT
  function openSlot(dateKey: string, taskKey: TaskKey) {
    setPendingSlot({ dateKey, taskKey });
    setModal("slot");
  }

  async function pickMe() {
    if (!pendingSlot) return;
    const { dateKey, taskKey } = pendingSlot;
    const newSlots = { ...slots, [dateKey]: { ...(slots[dateKey] || {}), [taskKey]: currentUser } };
    setSlots(newSlots);
    setModal(null);
    showToast("Prijavljeni ✓");
    await saveSlots(newSlots);
  }

  async function clearSlot() {
    if (!pendingSlot) return;
    const { dateKey, taskKey } = pendingSlot;
    const newSlots = { ...slots };
    if (newSlots[dateKey]) {
      delete newSlots[dateKey][taskKey];
      if (Object.keys(newSlots[dateKey]).length === 0) delete newSlots[dateKey];
    }
    setSlots(newSlots);
    setModal(null);
    showToast("Odjavljeni");
    await saveSlots(newSlots);
  }

  async function addMember() {
    const name = newMember.trim();
    if (!name || members.includes(name)) return;
    const updated = [...members, name];
    setMembers(updated);
    setNewMember("");
    await saveMembers(updated);
    showToast(`${name} dodan/a`);
  }

  async function removeMember(i: number) {
    const name = members[i];
    const updated = members.filter((_, idx) => idx !== i);
    setMembers(updated);
    await saveMembers(updated);
    showToast(`${name} odstranjen/a`);
  }

  const days = weekDays(currentWeek);
  const f = (d: Date) => `${d.getDate()}. ${MONTH_NAMES_SHORT[d.getMonth()]}`;

  // Counts for overview
  const counts: Record<string, number> = {};
  members.forEach(m => counts[m] = 0);
  Object.values(slots).forEach(day => Object.values(day).forEach(n => { if (n && counts[n] !== undefined) counts[n]++; }));
  const totalSlots = WEEKS * 7 * TASKS.length;
  const filled = Object.values(counts).reduce((a, b) => a + b, 0);
  const pct = Math.round(filled / totalSlots * 100);
  const maxCount = Math.max(...Object.values(counts), 1);

  return (
    <div className="flex justify-center min-h-screen bg-slate-100">
      <div className="w-full max-w-md min-h-screen bg-white flex flex-col relative">

        {/* TOPBAR */}
        {screen !== "login" && (
          <div style={{ background: "#0F4C6B" }} className="flex items-center justify-between px-4 py-3 flex-shrink-0">
            <div>
              <div className="text-white font-semibold text-base">❤️ Pomoč mami</div>
              <div style={{ color: "#9FE1CB" }} className="text-xs mt-0.5">20. jun – 31. jul 2026</div>
            </div>
            <button
              onClick={() => setModal("user")}
              style={{ background: "#1D9E75" }}
              className="flex items-center gap-1.5 text-white text-sm font-semibold px-3 py-1.5 rounded-full"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>
              {currentUser}
            </button>
          </div>
        )}

        {syncing && (
          <div style={{ background: "#1D9E75" }} className="text-white text-xs text-center py-1 font-medium">Shranjujem...</div>
        )}

        {/* SCREENS */}
        <div className="flex-1 overflow-y-auto">

          {/* LOGIN */}
          {screen === "login" && (
            <div className="flex flex-col items-center justify-center min-h-[70vh] gap-5 px-5 py-8">
              <div className="text-center">
                <div className="text-5xl mb-3">🏠</div>
                <h1 className="text-2xl font-bold text-slate-800">Pomoč mami</h1>
                <p className="text-sm text-slate-500 mt-2 max-w-xs leading-relaxed">
                  Prijavi se s svojim imenom, da se boš lahko vpisal na proste termine.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3 w-full max-w-xs">
                {members.map((m, i) => (
                  <button
                    key={m}
                    onClick={() => login(m)}
                    className="flex items-center gap-2.5 p-3 border-2 border-slate-200 rounded-xl bg-white hover:border-emerald-500 hover:bg-emerald-50 transition-all active:scale-95"
                  >
                    <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0" style={aStyle(i)}>{ini(m)}</div>
                    <span className="text-sm font-semibold text-slate-700">{m}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* URNIK */}
          {screen === "urnik" && (
            <div className="p-3.5">
              <div className="flex items-center justify-between mb-3">
                <button
                  onClick={() => setCurrentWeek(w => Math.max(0, w - 1))}
                  disabled={currentWeek === 0}
                  className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 rounded-lg text-sm text-slate-700 disabled:opacity-30"
                >‹ Nazaj</button>
                <span className="text-sm font-semibold text-slate-700">{currentWeek + 1}. teden · {f(days[0])} – {f(days[6])}</span>
                <button
                  onClick={() => setCurrentWeek(w => Math.min(WEEKS - 1, w + 1))}
                  disabled={currentWeek === WEEKS - 1}
                  className="flex items-center gap-1 px-3 py-1.5 border border-slate-200 rounded-lg text-sm text-slate-700 disabled:opacity-30"
                >Naprej ›</button>
              </div>

              {days.map(d => {
                const key = dk(d);
                const wi = (d.getDay() + 6) % 7;
                const isSat = wi === 5, isSun = wi === 6;
                const headBg = isSat ? "#EBF5FD" : isSun ? "#FDF4EB" : "#f1f5f9";
                return (
                  <div key={key} className="border border-slate-200 rounded-xl mb-2 overflow-hidden">
                    <div className="flex items-center justify-between px-3 py-2" style={{ background: headBg }}>
                      <span className="text-sm font-semibold text-slate-700">{DAY_NAMES[wi]}</span>
                      <span className="text-xs text-slate-500">{d.getDate()}. {MONTH_NAMES_LONG[d.getMonth()]}</span>
                    </div>
                    <div className="grid grid-cols-2">
                      {TASKS.map((t, ti) => {
                        const occ = (slots[key] || {})[t.key];
                        const isMe = occ === currentUser;
                        const isFree = !occ;
                        const canClick = isFree || isMe;
                        return (
                          <div
                            key={t.key}
                            onClick={() => canClick && openSlot(key, t.key)}
                            className={`p-2.5 border-t border-slate-200 min-h-[52px] transition-all ${ti % 2 === 1 ? "border-l border-slate-200" : ""} ${canClick ? "cursor-pointer active:scale-95" : "cursor-default"}`}
                            style={{ background: t.color }}
                          >
                            <div className="text-[10px] text-slate-500 font-medium mb-0.5">{t.label}</div>
                            {isMe && <div className="text-xs font-bold" style={{ color: t.textColor }}>✓ Ti</div>}
                            {!isMe && occ && <div className="text-xs text-slate-600">{occ}</div>}
                            {isFree && <div className="text-[11px] text-slate-400">+ prijavi se</div>}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* CLANI */}
          {screen === "clani" && (
            <div className="p-3.5">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-3">Pomočniki</div>
              {members.map((m, i) => (
                <div key={m} className="flex items-center gap-3 p-3 border border-slate-200 rounded-xl mb-2 bg-white">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0" style={aStyle(i)}>{ini(m)}</div>
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-slate-700">
                      {m}{m === currentUser && <span className="text-xs font-semibold ml-1.5" style={{ color: "#1D9E75" }}>(ti)</span>}
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">{counts[m] || 0} termin{(counts[m] || 0) === 1 ? "" : "ov"} prijavljenih</div>
                  </div>
                  <button onClick={() => removeMember(i)} className="text-red-400 hover:text-red-600 hover:bg-red-50 p-1.5 rounded-lg text-lg leading-none">✕</button>
                </div>
              ))}
              <div className="flex gap-2 mt-3">
                <input
                  value={newMember}
                  onChange={e => setNewMember(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && addMember()}
                  placeholder="Dodaj ime..."
                  maxLength={30}
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:border-emerald-500"
                />
                <button
                  onClick={addMember}
                  style={{ background: "#1D9E75" }}
                  className="text-white text-sm font-semibold px-4 py-2 rounded-lg flex items-center gap-1 hover:opacity-90"
                >+ Dodaj</button>
              </div>
            </div>
          )}

          {/* PREGLED */}
          {screen === "pregled" && (
            <div className="p-3.5">
              <div className="grid grid-cols-2 gap-2 mb-4">
                {[
                  { label: "Zapolnjeni termini", val: filled },
                  { label: "Pokritost", val: `${pct}%` },
                  { label: "Pomočniki", val: members.length },
                  { label: "Skupaj terminov", val: totalSlots },
                ].map(({ label, val }) => (
                  <div key={label} className="bg-slate-50 rounded-xl p-3">
                    <div className="text-xs text-slate-400 mb-1">{label}</div>
                    <div className="text-2xl font-bold text-slate-700">{val}</div>
                  </div>
                ))}
              </div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-3">Prispevki</div>
              {[...members].sort((a, b) => (counts[b] || 0) - (counts[a] || 0)).map(m => (
                <div key={m} className="flex items-center gap-2.5 mb-2">
                  <span className="text-sm text-slate-600 w-16 flex-shrink-0 truncate">{m}</span>
                  <div className="flex-1 bg-slate-200 rounded-full h-2 overflow-hidden">
                    <div className="h-2 rounded-full" style={{ background: "#1D9E75", width: `${Math.round((counts[m] || 0) / maxCount * 100)}%` }} />
                  </div>
                  <span className="text-xs text-slate-400 w-5 text-right">{counts[m] || 0}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* BOTTOMBAR */}
        {screen !== "login" && (
          <div style={{ background: "#0F2D3D" }} className="flex justify-around py-2.5 pb-safe flex-shrink-0">
            {(["urnik", "clani", "pregled"] as const).map(s => {
              const icons = { urnik: "📅", clani: "👥", pregled: "📊" };
              const labels = { urnik: "Urnik", clani: "Člani", pregled: "Pregled" };
              const active = screen === s;
              return (
                <button key={s} onClick={() => setScreen(s)} className="flex flex-col items-center gap-0.5 px-3 bg-transparent border-none cursor-pointer">
                  <span className="text-xl" style={{ opacity: active ? 1 : 0.5 }}>{icons[s]}</span>
                  <span className="text-[10px] font-semibold" style={{ color: active ? "#fff" : "#9FE1CB" }}>{labels[s]}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* SLOT MODAL */}
        {modal === "slot" && pendingSlot && (() => {
          const task = TASKS.find(t => t.key === pendingSlot.taskKey)!;
          const d = new Date(pendingSlot.dateKey);
          const current = (slots[pendingSlot.dateKey] || {})[pendingSlot.taskKey];
          const isMe = current === currentUser;
          return (
            <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: "rgba(0,0,0,0.45)" }} onClick={e => { if (e.target === e.currentTarget) setModal(null); }}>
              <div className="bg-white rounded-t-2xl p-5 w-full max-w-md">
                <div className="w-9 h-1 bg-slate-200 rounded-full mx-auto mb-4" />
                <div className="text-base font-bold text-slate-800 mb-1">{task.label}</div>
                <div className="text-sm text-slate-400 mb-4">
                  {DAY_NAMES_LONG[(d.getDay() + 6) % 7]}, {d.getDate()}. {MONTH_NAMES_LONG[d.getMonth()]}
                </div>
                <button
                  onClick={pickMe}
                  className={`w-full flex items-center gap-3 p-3 border-2 rounded-xl mb-3 transition-all ${isMe ? "border-emerald-500 bg-emerald-50" : "border-slate-200 hover:border-emerald-400 hover:bg-emerald-50"}`}
                >
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0" style={aStyle(members.indexOf(currentUser))}>{ini(currentUser)}</div>
                  <div className="text-left">
                    <div className="text-sm font-semibold text-slate-700">{currentUser}</div>
                    <div className="text-xs text-slate-400">{isMe ? "✓ Že prijavljen/a" : "Prijavi se za ta termin"}</div>
                  </div>
                </button>
                {isMe && (
                  <button onClick={clearSlot} className="w-full py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50 mb-2">
                    Odstrani mojo prijavo
                  </button>
                )}
                <button onClick={() => setModal(null)} className="w-full py-2.5 border border-slate-200 rounded-xl text-sm text-slate-400">
                  Prekliči
                </button>
              </div>
            </div>
          );
        })()}

        {/* USER MODAL */}
        {modal === "user" && (
          <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: "rgba(0,0,0,0.45)" }} onClick={e => { if (e.target === e.currentTarget) setModal(null); }}>
            <div className="bg-white rounded-t-2xl p-5 w-full max-w-md">
              <div className="w-9 h-1 bg-slate-200 rounded-full mx-auto mb-4" />
              <div className="text-base font-bold text-slate-800 mb-1">Zamenjaj uporabnika</div>
              <div className="text-sm text-slate-400 mb-4">Prijavi se z drugim imenom.</div>
              <div className="flex flex-col gap-2">
                {members.map((m, i) => (
                  <button key={m} onClick={() => { setCurrentUser(m); setModal(null); showToast(`Prijavljeni kot ${m}`); }}
                    className={`flex items-center gap-3 p-3 border-2 rounded-xl transition-all ${m === currentUser ? "border-emerald-500 bg-emerald-50" : "border-slate-200 hover:border-emerald-400"}`}
                  >
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold" style={aStyle(i)}>{ini(m)}</div>
                    <span className="text-sm font-semibold text-slate-700">{m}</span>
                  </button>
                ))}
              </div>
              <button onClick={() => setModal(null)} className="w-full mt-3 py-2.5 border border-slate-200 rounded-xl text-sm text-slate-400">Prekliči</button>
            </div>
          </div>
        )}

        {/* TOAST */}
        {toast && (
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-sm font-medium px-4 py-2.5 rounded-full z-50 whitespace-nowrap">
            {toast}
          </div>
        )}
      </div>
    </div>
  );
}
