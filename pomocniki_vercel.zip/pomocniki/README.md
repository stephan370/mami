# Pomoč mami — Setup

## 1. Firebase (brezplačno)

1. Pojdi na https://firebase.google.com → Get started → Nov projekt (npr. "pomocniki")
2. Levo meni → Build → **Realtime Database** → Create database → Start in **test mode** → Europe-west1
3. Kopiraj Database URL (npr. `https://pomocniki-xxx-default-rtdb.europe-west1.firebasedatabase.app`)
4. Levo meni → Project settings → General → Your apps → **Add app** → Web (</>)
5. Kopiraj vse vrednosti iz `firebaseConfig`

## 2. Vercel (brezplačno)

1. Ustvari račun na https://vercel.com (prijava z GitHub)
2. Na GitHubu ustvari nov repozitorij in poriniti ta projekt:
   ```
   git init
   git add .
   git commit -m "init"
   git remote add origin https://github.com/TVOJ_USERNAME/pomocniki.git
   git push -u origin main
   ```
3. Na Vercel → New Project → Import tega repozitorija
4. V Vercel → Settings → Environment Variables dodaj:

| Name | Value |
|------|-------|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | iz firebaseConfig |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | iz firebaseConfig |
| `NEXT_PUBLIC_FIREBASE_DATABASE_URL` | Database URL iz koraka 3 |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | iz firebaseConfig |

5. Klikni **Deploy** → dobiš link npr. `https://pomocniki.vercel.app`

## Lokalni razvoj

```bash
cp .env.local.example .env.local
# Izpolni .env.local z vrednostmi iz Firebase
npm install
npm run dev
```
